import { Component } from '@angular/core';

@Component({
 selector: 'pnr-root',
  templateUrl: './pnr.component.html',
styleUrls: ['./pnr.component.css']
})
export class PnrComponent {
  title = 'Management';
}