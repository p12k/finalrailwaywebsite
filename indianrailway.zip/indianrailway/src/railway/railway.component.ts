import { Component } from '@angular/core';

@Component({
  selector: 'rail-root',
  templateUrl: './railway.component.html',
  styleUrls: ['./railway.component.css']
})
export class railComponent {
  title = 'Management';
}