import { Component } from '@angular/core';

@Component({
 selector: 'chart-root',
  templateUrl: './chart.component.html',
styleUrls: ['./chart.component.css']
})
export class ChartComponent {
  title = 'Management';
}